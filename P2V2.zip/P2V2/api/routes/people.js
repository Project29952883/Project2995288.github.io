const express = require('express'); 
const router = express.Router() ; 
const mongoose = require('mongoose') ; 

const Person = require('../routes/models/person') ; 
//Display all elements
router.get('/', (req, res, next) => {
    Person.find()
    .exec()
    .then(docs => {
        console.log(docs);
        if(docs.length >= 0 ){
            res.status(200).json(docs);
        }else{
            res.status(404).json({
                message:'There are no entries in the databse'
            });
        }// Return if empty database
        

    }).catch(err => {
        console.log(err);
        res.status(500).json({
            error : err 
        }); 
    });

    }) ; 


router.post('/', (req, res, next) => {
  /* const person = {
        name: req.body.name,
        surname: req.body.surname,
        age: req.body.age 
   };*/
  
const person = new Person({
    _id: new mongoose.Types.ObjectId(),
    name: req.body.name,
    surname: req.body.surname,
    age: req.body.age

}); 
person.save().then(result => {
    console.log(result);
} )
.catch(err => console.log(err)); 


   
    res.status(201).json({
        message: 'Handling request POST requets to /people',
        createdPerson: person
    }) ; 
}) ; 
//Check if ID is valid length - > 13
router.get('/:personId', (req, res, next) => {
   const id = req.params.personId ; 
   Person.findById(id)
   .exec()
   .then(doc => {
       console.log("From database", doc);
       if(doc){
        res.status(200).json(doc) ; 

       }else {
           res.status(404).json({message: 'There is no record that has the ID you provided'});
       }
      
   })
   .catch(err => {
       console.log(err) ;
       res.status(500).json({error: err}) 
}); 
});




   /*if(id.length == 13 ){

       res.status(200).json({
           message: 'This id is the valid length of 13 ', 
            id: id 
        });
   }else{
       res.status(200).json({
           message: 'NOT a valid id number because length is not 13 ', 
           id: id
       }) ;
   } 
}) ; */

//UPDATE persons record
router.patch('/:personId', (req, res, next) => {
    const id = req.params.personId; 
    const updateOps ={} ;
    for (const ops of req.body){
        updateOps[ops.propName] = ops.value; 
    }
Person.update({_id: id }, {$set:updateOps})
.exec() 
.then(result => {
    console.log(result);
    res.status(200).json(result); 
})
.catch(err => {
    console.log(err);
    res.status(500).json({
        error : err
    })
}) ;
 }) ; 
//Delete invalid record
 router.delete('/:personId', (req, res, next) => {
     const id = req.params.personId ; 
 Person.remove({_id: id})
 .exec()
 .then(result => {
     res.status(200).json(result); 
 }) .catch(err => {
console.log(err); 

res.status(500).json({
error : err 
});
 }); 
     }) ; 

module.exports = router ; 